from django.urls import path
from m1 import views

urlpatterns = [

    path('add/', views.add),
    path('sub/', views.sub),
]