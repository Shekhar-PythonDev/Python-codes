
from django.contrib import admin
from django.urls import path, include
# Remove or correct this line; if you need to import views from each module, do it like this:
# from m1 import views as m1_views
# from m2 import views as m2_views
# from m3 import views as m3_views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('m1/', include('m1.urls')),
    path('m2/', include('m2.urls')),
    path('m3/', include('m3.urls')),

]
