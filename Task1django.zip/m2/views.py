from django.http import HttpResponse

# Create your views here.
def mul(request):
    a = 23
    b = 14
    c = a * b
    return HttpResponse(f"Addition:{a} * {b} = {c}")
def div(request):
    a = 23
    b = 14
    c = a / b
    return HttpResponse(f"Addition:{a} / {b} = {c}")