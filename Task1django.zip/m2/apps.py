from django.apps import AppConfig


class M2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'm2'
