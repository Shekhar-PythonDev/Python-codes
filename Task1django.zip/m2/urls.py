from django.urls import path
from m2 import views

urlpatterns = [

    path('mul/', views.mul),
    path('div/', views.div),
]