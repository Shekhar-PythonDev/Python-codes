from django.http import HttpResponse

# Create your views here.
def add(request):
    a = 23
    b = 14
    c = a + b
    return HttpResponse(f"Addition:{a} + {b} = {c}")
def sub(request):
    a = 23
    b = 14
    c = a - b
    return HttpResponse(f"Addition:{a} - {b} = {c}")