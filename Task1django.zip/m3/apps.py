from django.apps import AppConfig


class M3Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'm3'
