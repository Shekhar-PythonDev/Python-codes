
from django.urls import path
from m3 import views

urlpatterns = [

    path('add/', views.add),
    path('sub/', views.sub),
]